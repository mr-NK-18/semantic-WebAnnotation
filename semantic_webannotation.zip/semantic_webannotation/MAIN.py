import pickle
import re
import string as s

import matplotlib.pyplot as plt
import nltk
nltk.download()
nltk.download('wordnet')
import pandas as pd
from nltk.corpus import stopwords
import matplotlib.pyplot as plt

train_data = pd.read_csv('train1.csv')
test_data = pd.read_csv('test.csv')

print(train_data.head())
print(test_data.head())

print(train_data.info())

print("train ==>", train_data.shape)
print("test ==>", test_data.shape)

colors = ['red', 'green', 'blue', 'yellow']
train_data['Class Index'].value_counts().plot(kind='bar', color= colors)
plt.show()

test_data['Class Index'].value_counts().plot(kind='bar', color= colors)
plt.show()

train_x = train_data.Description
test_x = test_data.Description

train_y = train_data['Class Index']
test_y = test_data['Class Index']

training_x = train_data.Description
testing_x = test_data.Description

training_y = train_data['Class Index']
testing_y = test_data['Class Index']


def striphtml(data):
    p = re.compile(r'<.*?>')
    return p.sub('', data)


train_x = train_x.apply(striphtml)
print(train_x)
test_x = test_x.apply(striphtml)


def remove_url(data):
    return re.sub(r'\s*(?:https?://)?www\.\S*\.[A-Za-z]{2,5}\s*', ' ', data).strip()


train_x = train_x.apply(remove_url)
print(train_x)
print(test_x)


def word_tok(data):
    tokens = re.findall("[\w']+", data)
    #     print(tokens)
    return tokens


train_x = train_x.apply(word_tok)

test_x = test_x.apply(word_tok)


def remove_stopwords(data):
    stopWords = stopwords.words('english')
    new_list = []
    for i in data:
        if i.lower() not in stopWords:
            new_list.append(i)
    #     print(new_list)
    return new_list


train_x = train_x.apply(remove_stopwords)
test_x = test_x.apply(remove_stopwords)


def remove_punctuations(data):
    new_list = []
    for i in data:
        for j in s.punctuation:
            i = i.replace(j, '')
        new_list.append(i)
    return new_list


train_x = train_x.apply(remove_punctuations)
test_x = test_x.apply(remove_punctuations)


def remove_number(data):
    no_digit_list = []
    new_list = []

    for i in data:
        for j in s.digits:
            i = i.replace(j, '')
        no_digit_list.append(i)

    for i in no_digit_list:
        if i != '':
            new_list.append(i)
    return new_list


train_x = train_x.apply(remove_number)
test_x = test_x.apply(remove_number)

import nltk


def stemming(data):
    porter_stemmer = nltk.PorterStemmer()
    roots = [porter_stemmer.stem(i) for i in data]
    return roots
train_x = train_x.apply(stemming)
test_x = test_x.apply(stemming)

def lemmatization(data):
    lemmatizer = nltk.stem.WordNetLemmatizer()
    roots = [lemmatizer.lemmatize(i) for i in data]
    return roots

train_x = train_x.apply(lemmatization)
test_x = test_x.apply(lemmatization)


def remove_extraWords(data):
    extra_words = ['href', 'iii', 'lt', 'gt', 'ii', 'com', 'quot']

    new_list = []
    for i in data:
        if i not in extra_words:
            new_list.append(i)
    return new_list

train_x = train_x.apply(remove_extraWords)
test_x = test_x.apply(remove_extraWords)

train_x = [" ".join(map(str, lst)) for lst in train_x]
test_x = [" ".join(map(str, lst)) for lst in test_x]

from sklearn.feature_extraction.text import TfidfVectorizer

TfIdf = TfidfVectorizer(min_df=8,ngram_range=(1,3))
train_1 = TfIdf.fit_transform(train_x)
test_1 = TfIdf.transform(test_x)

print("no of features extracted")
print(len(TfIdf.get_feature_names()))
print(TfIdf.get_feature_names()[:100])

train_array = train_1.toarray()
test_array = test_1.toarray()
print(train_array.shape)
print(test_array.shape)

df = pd.DataFrame(train_array[:100], columns=TfIdf.get_feature_names())
print(df)

from sklearn.neural_network import MLPClassifier
from sklearn.metrics import f1_score, accuracy_score
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfTransformer

def news_models():
    new_model = Pipeline([
            ('vect' , TfidfVectorizer()),
            ('tfidf',TfidfTransformer()),
            ('MLP', MLPClassifier())])
    return new_model

model = news_models()
model.fit(train_x,train_y)


pred = model.predict(test_x)
print("first 20 actual labels")
print(test_y.tolist()[:20])
print("first 20 predicted labels")
print(pred.tolist()[:20])

print('======================// Evaluation of Results //===========================')
print()
print("F1 score of the model ==> ",f1_score(test_y,pred,average ='micro' ))
print('Accuracy of the model ==> ',round(accuracy_score(test_y,pred)*100,3),"%")


import joblib
# Save the model as a pickle in a file
joblib.dump(model, 'news_article_model.pkl')
# Load the model from the file
news_model = joblib.load('news_article_model.pkl')
news_model.predict(test_x)


def striphtml(data):
    p = re.compile(r'<.*?>')
    return p.sub('', data)


def remove_url(data):
    return re.sub(r'\s*(?:https?://)?www\.\S*\.[A-Za-z]{2,5}\s*', ' ', data).strip()


def lower_case(data):
    return data.lower()


def word_tok(data):
    tokens = re.findall("[\w']+", data)
    #     print(tokens)
    return tokens


def remove_stopwords(data):
    stopWords = stopwords.words('english')
    new_list = []
    for i in data:
        if i.lower() not in stopWords:
            new_list.append(i)
    #     print(new_list)
    return new_list


def remove_punctuations(data):
    new_list = []
    for i in data:
        for j in s.punctuation:
            i = i.replace(j, '')
        new_list.append(i)
    return new_list


def remove_number(data):
    no_digit_list = []
    new_list = []

    for i in data:
        for j in s.digits:
            i = i.replace(j, '')
        no_digit_list.append(i)

    for i in no_digit_list:
        if i != '':
            new_list.append(i)
    return new_list


def stemming(data):
    porter_stemmer = nltk.PorterStemmer()
    roots = [porter_stemmer.stem(i) for i in data]
    return roots


def lemmatization(data):
    lemmatizer = nltk.stem.WordNetLemmatizer()
    roots = [lemmatizer.lemmatize(i) for i in data]
    return roots


def remove_extraWords(data):
    extra_words = ['href', 'iii', 'lt', 'gt', 'ii', 'com', 'quot']

    new_list = []
    for i in data:
        if i not in extra_words:
            new_list.append(i)
    return new_list
userInput = 'Reuters - A group of technology companies\including Texas Instruments Inc. (TXN.N), STMicroelectronics\(STM.PA) and Broadcom Corp. (BRCM.O), on Thursday said they\will propose a new wireless networking standard up to 10 times he speed of the current generation.'
userInput = striphtml(userInput)
userInput = remove_url(userInput)
userInput = lower_case(userInput)
userInput = word_tok(userInput)
userInput = remove_stopwords(userInput)
userInput = remove_punctuations(userInput)
userInput = remove_number(userInput)
userInput = stemming(userInput)
userInput = lemmatization(userInput)
userInput = remove_extraWords(userInput)
userInput = [" ".join(map(str, userInput))]

result = news_model.predict(userInput)
if result[0] == 1:
    print("World News")
elif result[0] == 2:
    print('Sports News')
elif result[0] == 3:
    print('Business News')
elif result[0] == 4:
    print('Science-Technology News')