from flask import Flask, render_template, url_for, request
import pandas as pd
import joblib
import re
import string as s
import nltk

nltk.download('wordnet')
from nltk.corpus import stopwords

# Save the model as a pickle in a file
# You should already have the model saved as 'news_article_model.pkl'
news_model = joblib.load('news_article_model.pkl')

# Assuming you already have a trained TfIdf vectorizer
tfidf_vectorizer = joblib.load('tfidf_vectorizer.pkl')  # Load the TF-IDF vectorizer

app = Flask(__name__)


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/Predict')
def Predict():
    return render_template('Predict.html')


@app.route('/Result')
def Result():
    return render_template('Result.html')


def striphtml(data):
    p = re.compile(r'<.*?>')
    return p.sub('', str(data))  # Ensure data is string before applying regex


def remove_url(data):
    return re.sub(r'\s*(?:https?://)?www\.\S*\.[A-Za-z]{2,5}\s*', ' ', str(data)).strip()  # Convert to string


def lower_case(data):
    return str(data).lower()  # Convert to string and make lowercase


def word_tok(data):
    tokens = re.findall("[\w']+", str(data))  # Ensure data is string before tokenizing
    return tokens


def remove_stopwords(data):
    stopWords = stopwords.words('english')
    new_list = []
    for i in data:
        if str(i).lower() not in stopWords:  # Ensure it's lowercase
            new_list.append(i)
    return new_list


def remove_punctuations(data):
    new_list = []
    for i in data:
        for j in s.punctuation:
            i = str(i).replace(j, '')  # Convert to string before replacing punctuation
        new_list.append(i)
    return new_list


def remove_number(data):
    no_digit_list = []
    new_list = []
    for i in data:
        i = str(i)  # Ensure it's a string
        for j in s.digits:
            i = i.replace(j, '')
        no_digit_list.append(i)

    for i in no_digit_list:
        if i != '':
            new_list.append(i)
    return new_list


def stemming(data):
    porter_stemmer = nltk.PorterStemmer()
    roots = [porter_stemmer.stem(str(i)) for i in data]  # Convert to string before stemming
    return roots


def lemmatization(data):
    lemmatizer = nltk.stem.WordNetLemmatizer()
    roots = [lemmatizer.lemmatize(str(i)) for i in data]  # Convert to string before lemmatization
    return roots


def remove_extraWords(data):
    extra_words = ['href', 'iii', 'lt', 'gt', 'ii', 'com', 'quot']

    new_list = []
    for i in data:
        if str(i) not in extra_words:  # Convert to string before checking
            new_list.append(i)
    return new_list


@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        comment = request.form['comment']
        userInput = str(comment)  # Ensure it's a string

        # Proceed with preprocessing as before...
        userInput = striphtml(userInput)
        userInput = remove_url(userInput)
        userInput = lower_case(userInput)
        userInput = word_tok(userInput)
        userInput = remove_stopwords(userInput)
        userInput = remove_punctuations(userInput)
        userInput = remove_number(userInput)
        userInput = stemming(userInput)
        userInput = lemmatization(userInput)
        userInput = remove_extraWords(userInput)
        userInput = [" ".join(map(str, userInput))]

        # Predict using the trained model
        result = news_model.predict(userInput)
        my_prediction = ''
        if result[0] == 1:
            my_prediction = "World "
        elif result[0] == 2:
            my_prediction = 'Sports '
        elif result[0] == 3:
            my_prediction = 'Business '
        elif result[0] == 4:
            my_prediction = 'Science-Technology '

    return render_template('Result.html', result=my_prediction)


if __name__ == '__main__':
    app.run(debug=True)
