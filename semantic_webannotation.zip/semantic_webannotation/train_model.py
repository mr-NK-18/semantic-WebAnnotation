import pandas as pd
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score

# Load the dataset
df = pd.read_csv('TRAIN.csv')  # Change this if using 'train1.csv'

# Print column names for debugging
print("Columns in CSV:", df.columns)

# Rename columns to match expected format
df.rename(columns={'Description': 'text', 'Class Index': 'label'}, inplace=True)

# Ensure no NaN values in 'text' and 'label' columns
df['text'] = df['text'].fillna('')  # Replace NaN with empty string in text column
df['label'] = df['label'].fillna(0).astype(int)  # Replace NaN with 0 in label column and convert to integer

# Ensure 'text' column is of string type (even if some values are integers or NaN)
df['text'] = df['text'].apply(lambda x: str(x) if isinstance(x, str) else str(x))

# Check for missing values and drop any rows with NaN in 'text' or 'label'
df.dropna(subset=['text', 'label'], inplace=True)

# Verify columns after cleaning
print("Columns after cleaning:", df.columns)
print("First few rows of cleaned data:\n", df.head())

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(df['text'], df['label'], test_size=0.2, random_state=42)

# Create a TF-IDF vectorizer and Naive Bayes classifier pipeline
model_pipeline = Pipeline([
    ('tfidf', TfidfVectorizer(stop_words='english')),
    ('classifier', MultinomialNB())
])

# Train the model
model_pipeline.fit(X_train, y_train)

# Predict on the test set
y_pred = model_pipeline.predict(X_test)

# Print accuracy
accuracy = accuracy_score(y_test, y_pred)
print(f'✅ Model Trained Successfully! Accuracy: {accuracy:.2f}')

# Save the trained model
joblib.dump(model_pipeline, 'news_article_model.pkl')
print("✅ Model saved as 'news_article_model.pkl'")
